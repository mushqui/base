import xbmcaddon

MainBase = 'https://raw.githubusercontent.com/mushqui/base/main/main.xml'
addon = xbmcaddon.Addon('plugin.video.Rising.Tides')